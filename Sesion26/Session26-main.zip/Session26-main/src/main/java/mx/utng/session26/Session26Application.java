package mx.utng.session26;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Session26Application {

	public static void main(String[] args) {
		SpringApplication.run(Session26Application.class, args);
	}

}
