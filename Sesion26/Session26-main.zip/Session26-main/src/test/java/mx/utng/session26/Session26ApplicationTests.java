package mx.utng.session26;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Session26ApplicationTests {

	@Test
	void contextLoads() {
	}

}
